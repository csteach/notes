### Notes - Extras - HTML5

A collection of extra documents and resources on HTML5 for Comp 424.
