### Notes - Extras - HTML

A collection of extra documents and resources on HTML for Comp 424.
